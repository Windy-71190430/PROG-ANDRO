package id.ac.ukdw.pertemuan6_71190430

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment

class FragmentB : Fragment(){
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val b = inflater.inflate(R.layout.b_fragment, container, false)
        val btnB = b.findViewById<Button>(R.id.btnB)
        btnB.setOnClickListener {
            val i = Intent(context,Hal3Activity::class.java)
            context?.startActivity(i)
        }

        return b
    }
}